<?php return array (
  'card-table' => 'App\\Http\\Livewire\\CardTable',
  'permission-table' => 'App\\Http\\Livewire\\PermissionTable',
  'role-table' => 'App\\Http\\Livewire\\RoleTable',
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);