<?php return array (
  'card-table' => 'App\\Http\\Livewire\\CardTable',
  'order-table' => 'App\\Http\\Livewire\\OrderTable',
  'permission-table' => 'App\\Http\\Livewire\\PermissionTable',
  'role-table' => 'App\\Http\\Livewire\\RoleTable',
  'user-table' => 'App\\Http\\Livewire\\UserTable',
);